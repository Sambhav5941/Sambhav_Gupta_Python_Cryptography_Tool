# Python Cryptography Tool — AES-256-GCM

A small educational command-line project demonstrating authenticated encryption and decryption with AES-256-GCM.

## Features
- Encrypts text using AES-256-GCM.
- Generates a fresh random 96-bit nonce for each encryption.
- Verifies data integrity during decryption; altered tokens or the wrong key fail authentication.
- Stores a local demo key in `demo_key.bin` (excluded from Git by `.gitignore`).

## Requirements
- Python 3.10+
- `pip`

## Run on Windows / VS Code
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

On macOS/Linux, activate with `source .venv/bin/activate`.

## Test
1. Run `python main.py`.
2. Select `1`, enter sample text such as `Cybersecurity Internship Demo`.
3. Copy the encrypted token.
4. Select `2`, paste the token, and verify the original text is returned.
5. Try changing one character in the token; decryption should fail authentication.

## Security notes
- This is an educational local demo, not a production key-management system.
- Keep `demo_key.bin` private and backed up securely if you need to decrypt old tokens.
- If the key is lost, encrypted data cannot be recovered.
- Never reuse a nonce with the same AES-GCM key. This program generates a random nonce for each encryption; high-volume production systems need a carefully designed nonce strategy.
- Do not commit keys, passwords, or sensitive data to GitHub.
- Use established cryptographic libraries; do not implement AES primitives yourself.

## Learning outcomes
AES, symmetric encryption, authenticated encryption, nonce usage, integrity checking, key handling, and secure coding.

## Suggested repository description
`Educational Python project demonstrating AES-256-GCM text encryption and authenticated decryption.`
