"""
Secure File/Text Encryption Demo
Educational project for cybersecurity internship.

Uses AES-256-GCM via the Python cryptography package.
Never hard-code or share real encryption keys.
"""
import os
import base64
import getpass
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

KEY_FILE = "demo_key.bin"
NONCE_SIZE = 12

def load_or_create_key():
    """Load a local demo key or create a new 256-bit key."""
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, "rb") as f:
            key = f.read()
        if len(key) != 32:
            raise ValueError("Key file must contain exactly 32 bytes.")
        return key
    key = AESGCM.generate_key(bit_length=256)
    with open(KEY_FILE, "wb") as f:
        f.write(key)
    try:
        os.chmod(KEY_FILE, 0o600)
    except OSError:
        pass
    print(f"Created local key file: {KEY_FILE}")
    print("Keep this key private. Anyone with it can decrypt your data.")
    return key

def encrypt_text(text, key):
    nonce = os.urandom(NONCE_SIZE)  # unique random nonce for each encryption
    ciphertext = AESGCM(key).encrypt(nonce, text.encode("utf-8"), None)
    return base64.b64encode(nonce + ciphertext).decode("ascii")

def decrypt_text(token, key):
    raw = base64.b64decode(token.encode("ascii"), validate=True)
    if len(raw) < NONCE_SIZE + 16:
        raise ValueError("Encrypted data is too short or invalid.")
    nonce, ciphertext = raw[:NONCE_SIZE], raw[NONCE_SIZE:]
    return AESGCM(key).decrypt(nonce, ciphertext, None).decode("utf-8")

def main():
    print("=" * 48)
    print(" AES-256-GCM Encryption / Decryption Demo")
    print("=" * 48)
    key = load_or_create_key()

    while True:
        print("\\n1. Encrypt text")
        print("2. Decrypt token")
        print("3. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            text = getpass.getpass("Text to encrypt (hidden): ")
            token = encrypt_text(text, key)
            print("\\nEncrypted token (copy it somewhere safe):")
            print(token)
        elif choice == "2":
            token = input("Paste encrypted token: ").strip()
            try:
                print("\\nDecrypted text:")
                print(decrypt_text(token, key))
            except (ValueError, InvalidTag, UnicodeDecodeError) as exc:
                print(f"Could not decrypt: {exc}")
                print("Check the token and ensure demo_key.bin is the original key.")
        elif choice == "3":
            print("Exiting.")
            break
        else:
            print("Please choose 1, 2, or 3.")

if __name__ == "__main__":
    main()
